#!/bin/bash
echo "--- Open Source Research Goal ---"
read -p "What medical problem are you solving? " PROBLEM
read -p "What Python library will you use? " LIBRARY

FILENAME="manifesto.txt"
echo "Project Goal: $PROBLEM" > $FILENAME
echo "Primary Tool: $LIBRARY" >> $FILENAME
echo "Statement: Standing on the shoulders of giants via Open Source." >> $FILENAME

echo "--------------------------------"
echo "Manifesto saved to $FILENAME:"
cat $FILENAME
