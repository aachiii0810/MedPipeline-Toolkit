#!/bin/bash
REQUIRED_PKG="python3"

if command -v $REQUIRED_PKG &> /dev/null; then
    echo "SUCCESS: $REQUIRED_PKG is installed."
    echo "Version Details: $($REQUIRED_PKG --version)"
else
    echo "ERROR: $REQUIRED_PKG is NOT installed. Medical scripts will fail."
fi
