#!/bin/bash
FOLDERS=("Patient_MRI" "Blood_Reports" "DNA_Sequences" "Ethics_Approval")

echo "Initializing Clinical Trial Directory..."
for FOLDER in "${FOLDERS[@]}"
do
    mkdir -p "$FOLDER"
    echo "Folder Created: $FOLDER"
done

echo "Current Directory Status:"
ls -F
