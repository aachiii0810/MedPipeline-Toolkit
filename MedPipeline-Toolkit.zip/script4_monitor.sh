#!/bin/bash
echo "10:00 - HR: 72 (Normal)" > vitals.log
echo "10:05 - HR: 145 (CRITICAL_HIGH)" >> vitals.log
echo "10:10 - HR: 75 (Normal)" >> vitals.log

LOG_FILE="vitals.log"
echo "Scanning $LOG_FILE for emergencies..."

while IFS= read -r LINE; do
    if [[ "$LINE" == *"CRITICAL"* ]]; then
        echo "ALERT DETECTED: $LINE"
    fi
done < "$LOG_FILE"
