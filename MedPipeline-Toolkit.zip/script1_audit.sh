#!/bin/bash
NAME="[Your Name Here]"
SYSTEM_OS=$(hostnamectl | grep "Operating System" | cut -d: -f2)
KERNEL=$(uname -r)

echo "--- Biomedical Open Source Audit ---"
echo "Auditor: $NAME"
echo "OS Environment:$SYSTEM_OS"
echo "Kernel Version: $KERNEL"
echo "Date of Audit: $(date)"
