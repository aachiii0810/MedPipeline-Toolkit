#!/bin/bash

echo "===== BioAudit CLI Started ====="

# Script 1: Auditor Identity
NAME="[Your Name Here]"
SYSTEM_OS=$(hostnamectl | grep "Operating System" | cut -d: -f2)
KERNEL=$(uname -r)

echo "--- Biomedical Open Source Audit ---"
echo "Auditor: $NAME"
echo "OS Environment:$SYSTEM_OS"
echo "Kernel Version: $KERNEL"
echo "Date of Audit: $(date)"

# Script 2: Python Dependency Check
REQUIRED_PKG="python3"

if command -v $REQUIRED_PKG &> /dev/null; then
    echo "SUCCESS: $REQUIRED_PKG is installed."
    echo "Version Details: $($REQUIRED_PKG --version)"
else
    echo "ERROR: $REQUIRED_PKG is NOT installed. Medical scripts will fail."
fi

# Script 3: Clinical Folder Creator
FOLDERS=("Patient_MRI" "Blood_Reports" "DNA_Sequences" "Ethics_Approval")

echo "Initializing Clinical Trial Directory..."
for FOLDER in "${FOLDERS[@]}"
do
    mkdir -p "$FOLDER"
    echo "Folder Created: $FOLDER"
done
echo "Current Directory Status:"
ls -F

# Script 4: Heart Rate Log Monitor
echo "10:00 - HR: 72 (Normal)" > vitals.log
echo "10:05 - HR: 145 (CRITICAL_HIGH)" >> vitals.log
echo "10:10 - HR: 75 (Normal)" >> vitals.log

LOG_FILE="vitals.log"
echo "Scanning $LOG_FILE for emergencies..."

while IFS= read -r LINE; do
    if [[ "$LINE" == *"CRITICAL"* ]]; then
        echo "ALERT DETECTED: $LINE"
    fi
done < "$LOG_FILE"

# Script 5: Bio-Engineering Manifesto
echo "--- Open Source Research Goal ---"
read -p "What medical problem are you solving? " PROBLEM
read -p "What Python library will you use? " LIBRARY

FILENAME="manifesto.txt"
echo "Project Goal: $PROBLEM" > $FILENAME
echo "Primary Tool: $LIBRARY" >> $FILENAME
echo "Statement: Standing on the shoulders of giants via Open Source." >> $FILENAME

echo "--------------------------------"
echo "Manifesto saved to $FILENAME:"
cat $FILENAME

echo "===== Process Completed ====="
